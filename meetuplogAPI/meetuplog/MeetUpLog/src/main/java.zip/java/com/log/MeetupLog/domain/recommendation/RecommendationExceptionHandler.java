package com.log.MeetupLog.domain.recommendation;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientResponseException;

import java.util.Map;

@RestControllerAdvice(assignableTypes = RecommendationController.class)
public class RecommendationExceptionHandler {

    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity<Object> forbidden(IllegalStateException exception) {
        return ResponseEntity.status(403).body(Map.of(
                "error", Map.of("code", "ROOM_ACCESS_DENIED", "message", exception.getMessage(), "retryable", false)
        ));
    }

    @ExceptionHandler(RestClientResponseException.class)
    public ResponseEntity<Object> downstreamError(RestClientResponseException exception) {
        String responseBody = exception.getResponseBodyAsString();
        Object body = responseBody == null || responseBody.isBlank()
                ? Map.of("error", Map.of(
                    "code", "ML_SERVICE_ERROR",
                    "message", "추천 모델 요청을 처리하지 못했습니다.",
                    "retryable", exception.getStatusCode().is5xxServerError()
                ))
                : responseBody;

        return ResponseEntity.status(exception.getStatusCode())
                .contentType(MediaType.APPLICATION_JSON)
                .body(body);
    }

    @ExceptionHandler(ResourceAccessException.class)
    public ResponseEntity<Object> unavailable(ResourceAccessException exception) {
        return ResponseEntity.status(503).body(Map.of(
                "error", Map.of(
                        "code", "ML_SERVICE_UNAVAILABLE",
                        "message", "AI 추천 서비스에 연결할 수 없습니다.",
                        "retryable", true
                )
        ));
    }
}
