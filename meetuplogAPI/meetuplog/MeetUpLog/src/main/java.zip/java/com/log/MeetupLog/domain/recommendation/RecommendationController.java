package com.log.MeetupLog.domain.recommendation;

import com.fasterxml.jackson.annotation.JsonAlias;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.ObjectMapper;
import com.log.MeetupLog.domain.chat.dto.ChatMessageDto;
import com.log.MeetupLog.domain.chat.entity.ChatMessage;
import com.log.MeetupLog.domain.chat.repository.ChatMessageRepository;
import com.log.MeetupLog.domain.chat.service.ChatService;
import com.log.MeetupLog.domain.room.entity.MemberStatus;
import com.log.MeetupLog.domain.room.dto.RoomDecisionConfirmRequest;
import com.log.MeetupLog.domain.room.repository.ChatRoomMemberRepository;
import com.log.MeetupLog.domain.room.service.RoomDecisionService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.MediaType;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.time.OffsetDateTime;

@RestController
@RequestMapping("/api/v1/rooms/{roomId}/ai")
@RequiredArgsConstructor
@Slf4j
public class RecommendationController {

    private static final int MAX_SYNC_MESSAGES = 200;

    private final RestClient mlRestClient;
    private final ChatMessageRepository chatMessageRepository;
    private final ChatRoomMemberRepository chatRoomMemberRepository;
    private final ChatService chatService;
    private final RoomDecisionService roomDecisionService;
    private final SimpMessageSendingOperations messagingTemplate;
    private final ObjectMapper objectMapper;

    public record RecommendationRequest(
            @JsonAlias("round_id") String roundId,
            @JsonAlias("allowed_providers") List<Integer> allowedProviders,
            @JsonAlias("allowed_provider_types") List<String> allowedProviderTypes,
            @JsonAlias("include_unknown_watch_path") Boolean includeUnknownWatchPath,
            @JsonAlias("require_now_playing") Boolean requireNowPlaying,
            @JsonAlias("excluded_movie_ids") List<String> excludedMovieIds
    ) {
    }

    public record RecommendationEventRequest(
            @JsonAlias("round_id") @NotBlank String roundId,
            @JsonAlias("event_type") @NotBlank String eventType,
            @JsonAlias("movie_id") String movieId,
            @JsonAlias("rank_no") Integer rankNo,
            @JsonAlias("model_version") String modelVersion,
            Map<String, Object> payload
    ) {
    }

    public record RecommendationConfirmRequest(
            @JsonAlias("round_id") @NotBlank String roundId,
            @JsonAlias("movie_id") @NotBlank String movieId,
            @JsonAlias("rank_no") Integer rankNo,
            @JsonAlias("model_version") String modelVersion,
            Map<String, Object> movie
    ) {
    }

    @PostMapping("/recommendations")
    public Object recommend(
            @AuthenticationPrincipal Long userId,
            @PathVariable Long roomId,
            @RequestBody(required = false) RecommendationRequest request
    ) {
        requireActiveMember(roomId, userId);

        String roundId = request != null && request.roundId() != null
                && !request.roundId().isBlank()
                ? request.roundId()
                : "room-" + roomId + "-" + UUID.randomUUID();

        Map<String, Object> syncResponse = syncRecentMessages(roomId, roundId);
        Object stateVersion = syncResponse.get("state_version");

        Map<String, Object> body = new HashMap<>();
        body.put("round_id", roundId);
        if (stateVersion != null) body.put("expected_state_version", stateVersion);
        body.put("allowed_providers", listOrEmpty(request == null ? null : request.allowedProviders()));
        body.put("allowed_provider_types", listOrEmpty(request == null ? null : request.allowedProviderTypes()));
        body.put("limit", 3);
        body.put("include_unknown_watch_path",
                request == null || request.includeUnknownWatchPath() == null || request.includeUnknownWatchPath());
        body.put("require_now_playing", request != null && Boolean.TRUE.equals(request.requireNowPlaying()));
        body.put("excluded_movie_ids", listOrEmpty(request == null ? null : request.excludedMovieIds()));

        return mlRestClient.post()
                .uri("/v1/chat/rooms/{roomId}/recommendations", roomId)
                .contentType(MediaType.APPLICATION_JSON)
                .body(body)
                .retrieve()
                .body(Object.class);
    }

    @PostMapping("/events")
    public Object recordEvent(
            @AuthenticationPrincipal Long userId,
            @PathVariable Long roomId,
            @Valid @RequestBody RecommendationEventRequest request
    ) {
        requireActiveMember(roomId, userId);

        Map<String, Object> body = new HashMap<>();
        body.put("event_id", UUID.randomUUID().toString());
        body.put("room_id", roomId.toString());
        body.put("round_id", request.roundId());
        body.put("event_type", request.eventType());
        body.put("user_id", userId.toString());
        if (request.movieId() != null) body.put("movie_id", request.movieId());
        if (request.rankNo() != null) body.put("rank_no", request.rankNo());
        if (request.modelVersion() != null) body.put("model_version", request.modelVersion());
        body.put("payload", request.payload() == null ? Map.of() : request.payload());

        return mlRestClient.post()
                .uri("/v1/recommendation-events")
                .contentType(MediaType.APPLICATION_JSON)
                .body(body)
                .retrieve()
                .body(Object.class);
    }

    @PostMapping("/confirm")
    @Transactional
    public ChatMessageDto confirmRecommendation(
            @AuthenticationPrincipal Long userId,
            @PathVariable Long roomId,
            @Valid @RequestBody RecommendationConfirmRequest request
    ) {
        if (request.movie() == null || request.movie().isEmpty()) {
            throw new IllegalArgumentException("확정할 영화 정보가 필요합니다.");
        }

        String movieTitle = String.valueOf(request.movie().getOrDefault("title", "")).trim();
        if (movieTitle.isBlank()) {
            throw new IllegalArgumentException("확정할 영화 제목이 필요합니다.");
        }

        roomDecisionService.confirm(
                userId,
                roomId,
                new RoomDecisionConfirmRequest(request.movieId(), movieTitle)
        );

        Map<String, Object> eventBody = new HashMap<>();
        eventBody.put("event_id", UUID.randomUUID().toString());
        eventBody.put("room_id", roomId.toString());
        eventBody.put("round_id", request.roundId());
        eventBody.put("event_type", "SELECT");
        eventBody.put("user_id", userId.toString());
        eventBody.put("movie_id", request.movieId());
        if (request.rankNo() != null) eventBody.put("rank_no", request.rankNo());
        if (request.modelVersion() != null) eventBody.put("model_version", request.modelVersion());
        eventBody.put("payload", Map.of("movie", request.movie()));

        Map<String, Object> card = new HashMap<>();
        card.put("version", 1);
        card.put("roundId", request.roundId());
        card.put("confirmedAt", OffsetDateTime.now().toString());
        card.put("movie", request.movie());

        ChatMessageDto saved = chatService.saveDecisionCard(
                roomId,
                writeDecisionCard(card),
                readLong(request.movie().get("tmdbId"), request.movie().get("tmdb_id"))
        );
        afterCommit(() -> {
            try {
                mlRestClient.post()
                        .uri("/v1/recommendation-events")
                        .contentType(MediaType.APPLICATION_JSON)
                        .body(eventBody)
                        .retrieve()
                        .toBodilessEntity();
            } catch (RuntimeException exception) {
                log.warn("AI recommendation selection event delivery failed: roomId={}", roomId, exception);
            }
            messagingTemplate.convertAndSend("/sub/room/" + roomId, saved);
        });
        return saved;
    }

    @GetMapping("/health")
    public Object health(@AuthenticationPrincipal Long userId, @PathVariable Long roomId) {
        requireActiveMember(roomId, userId);
        return mlRestClient.get().uri("/health").retrieve().body(Object.class);
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> syncRecentMessages(Long roomId, String roundId) {
        List<ChatMessage> textMessages = new ArrayList<>(
                chatMessageRepository.findRecentAnalyzableMessages(
                        roomId,
                        ChatMessage.MessageType.TEXT,
                        ChatMessage.MessageStatus.DELETED,
                        PageRequest.of(0, MAX_SYNC_MESSAGES)
                )
        );
        Collections.reverse(textMessages);
        List<Map<String, Object>> messages = new ArrayList<>();

        for (ChatMessage message : textMessages) {
            Map<String, Object> item = new HashMap<>();
            item.put("message_id", message.getId());
            item.put("user_id", message.getSenderId().toString());
            item.put("text", message.getContent());
            if (message.getReplyToMessageId() != null) item.put("reply_to_message_id", message.getReplyToMessageId());
            messages.add(item);
        }

        Object response = mlRestClient.post()
                .uri("/v1/chat/rooms/{roomId}/sync", roomId)
                .contentType(MediaType.APPLICATION_JSON)
                .body(Map.of("round_id", roundId, "messages", messages))
                .retrieve()
                .body(Object.class);

        return response instanceof Map<?, ?> map ? (Map<String, Object>) map : Map.of();
    }

    private void requireActiveMember(Long roomId, Long userId) {
        if (roomId == null || userId == null ||
                !chatRoomMemberRepository.existsByRoomIdAndUserIdAndStatus(roomId, userId, MemberStatus.ACTIVE)) {
            throw new IllegalStateException("참여 중인 채팅방에서만 AI 추천을 이용할 수 있습니다.");
        }
    }

    private String writeDecisionCard(Map<String, Object> card) {
        try {
            return objectMapper.writeValueAsString(card);
        } catch (JacksonException exception) {
            throw new IllegalArgumentException("확정 영화 정보를 저장할 수 없습니다.", exception);
        }
    }

    private Long readLong(Object... values) {
        for (Object value : values) {
            if (value instanceof Number number) return number.longValue();
            if (value instanceof String text && !text.isBlank()) {
                try {
                    return Long.valueOf(text);
                } catch (NumberFormatException ignored) {}
            }
        }
        return null;
    }

    private static <T> List<T> listOrEmpty(List<T> value) {
        return value == null ? List.of() : value;
    }

    private void afterCommit(Runnable action) {
        if (!TransactionSynchronizationManager.isSynchronizationActive()) {
            action.run();
            return;
        }
        TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
            @Override
            public void afterCommit() {
                action.run();
            }
        });
    }
}
