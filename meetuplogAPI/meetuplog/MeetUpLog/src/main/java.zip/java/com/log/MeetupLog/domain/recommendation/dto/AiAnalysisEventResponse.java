package com.log.MeetupLog.domain.recommendation.dto;

import lombok.Builder;
import lombok.Getter;

import java.time.LocalDateTime;

@Getter
@Builder
public class AiAnalysisEventResponse {
    private String eventType;
    private Long roomId;
    private String analysisId;
    private String message;
    private LocalDateTime occurredAt;
}
