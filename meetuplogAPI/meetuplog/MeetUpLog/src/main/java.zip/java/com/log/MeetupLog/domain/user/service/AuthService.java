package com.log.MeetupLog.domain.user.service;

import com.log.MeetupLog.domain.user.dto.AuthResponse;
import com.log.MeetupLog.domain.user.dto.GuestLoginRequest;
import com.log.MeetupLog.domain.user.dto.GuestLoginResponse;
import com.log.MeetupLog.domain.user.dto.LoginRequest;
import com.log.MeetupLog.domain.user.dto.SignUpRequest;
import com.log.MeetupLog.domain.user.entity.AccountStatus;
import com.log.MeetupLog.domain.user.entity.AccountType;
import com.log.MeetupLog.domain.user.entity.Role;
import com.log.MeetupLog.domain.user.entity.User;
import com.log.MeetupLog.domain.user.repository.UserRepository;
import com.log.MeetupLog.global.error.ApiException;
import com.log.MeetupLog.global.security.jwt.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtTokenProvider;

    @Transactional
    public AuthResponse signUp(SignUpRequest request) {
        String email = normalizeEmail(request.getEmail());
        String nickname = request.getNickname().trim();

        User existingUser = userRepository.findByEmail(email).orElse(null);
        if (existingUser != null) {
            if (existingUser.getAccountStatus() == AccountStatus.ACTIVE) {
                throw new ApiException(
                        HttpStatus.CONFLICT,
                        "DUPLICATE_EMAIL",
                        "이미 사용 중인 이메일입니다."
                );
            }

            existingUser.withdraw(
                    WithdrawnAccountEmail.anonymized(existingUser.getUserId()),
                    "탈퇴한 사용자#" + existingUser.getUserId(),
                    WithdrawnAccountEmail.fingerprint(email)
            );
            userRepository.saveAndFlush(existingUser);
        }

        if (userRepository.existsByNickname(nickname)) {
            throw new ApiException(
                    HttpStatus.CONFLICT,
                    "DUPLICATE_NICKNAME",
                    "이미 사용 중인 닉네임입니다."
            );
        }

        User savedUser = userRepository.save(User.builder()
                .email(email)
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .nickname(nickname)
                .accountType(AccountType.MEMBER)
                .role(Role.USER)
                .accountStatus(AccountStatus.ACTIVE)
                .build());

        return createAuthResponse(savedUser);
    }

    public boolean isEmailAvailable(String email) {
        String normalizedEmail = normalizeEmail(email);
        return userRepository.findByEmail(normalizedEmail)
                .map(user -> user.getAccountStatus() != AccountStatus.ACTIVE)
                .orElse(true);
    }

    public boolean isNicknameAvailable(String nickname) {
        return !userRepository.existsByNickname(nickname.trim());
    }

    public AuthResponse login(LoginRequest request) {
        String email = normalizeEmail(request.getEmail());
        User user = userRepository.findByEmail(email).orElse(null);

        if (user == null) {
            if (isWithdrawnEmail(email)) {
                throw new ApiException(
                        HttpStatus.GONE,
                        "WITHDRAWN_ACCOUNT",
                        "탈퇴한 계정입니다."
                );
            }
            throw new ApiException(
                        HttpStatus.NOT_FOUND,
                        "ACCOUNT_NOT_FOUND",
                        "존재하지 않는 계정입니다."
            );
        }

        if (user.getAccountStatus() != AccountStatus.ACTIVE) {
            throw new ApiException(
                    HttpStatus.GONE,
                    "WITHDRAWN_ACCOUNT",
                    "탈퇴한 계정입니다."
            );
        }

        if (user.getPasswordHash() == null ||
                !passwordEncoder.matches(request.getPassword(), user.getPasswordHash())) {
            throw new ApiException(
                    HttpStatus.UNAUTHORIZED,
                    "INVALID_CREDENTIALS",
                    "이메일 또는 비밀번호가 일치하지 않습니다."
            );
        }

        return createAuthResponse(user);
    }

    @Transactional
    public GuestLoginResponse createGuestUser(GuestLoginRequest request) {
        User savedUser = userRepository.save(User.createGuest(request.getNickname().trim()));
        String token = createToken(savedUser);

        return GuestLoginResponse.builder()
                .userId(savedUser.getUserId())
                .nickname(savedUser.getNickname())
                .accountType(savedUser.getAccountType().name())
                .accountToken(token)
                .build();
    }

    private AuthResponse createAuthResponse(User user) {
        return AuthResponse.builder()
                .accountToken(createToken(user))
                .userId(user.getUserId())
                .email(user.getEmail())
                .nickname(user.getNickname())
                .accountType(user.getAccountType())
                .build();
    }

    private String createToken(User user) {
        return jwtTokenProvider.createAccessToken(
                user.getUserId(),
                user.getAccountType().name(),
                user.getRole().name()
        );
    }

    private String normalizeEmail(String email) {
        return WithdrawnAccountEmail.normalize(email);
    }

    private boolean isWithdrawnEmail(String email) {
        String emailHash = WithdrawnAccountEmail.fingerprint(email);
        return emailHash != null && userRepository.existsByWithdrawnEmailHash(emailHash);
    }
}
