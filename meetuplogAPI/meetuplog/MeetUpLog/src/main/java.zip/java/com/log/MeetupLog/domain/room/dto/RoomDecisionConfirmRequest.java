package com.log.MeetupLog.domain.room.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class RoomDecisionConfirmRequest {
    private String movieKey;
    private String movieTitle;
}
